/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1.java;

/**
 *
 * @author msi
 */
public class Homework1Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Begin of arguments input sample
		if (args.length > 0) {
			String input = args[0];
			if (input.equalsIgnoreCase("251-*32*+")) {
				System.out.println("(2*(5-1))+(3*2)=14");
			}
		}
		// End of arguments input sample
		
		// TODO: Implement your project here
        String x = "251-*32*+";
        int n = x.length();
        Stack s = new Stack(10);
        Node target;
        int []Ans = new int[10];
        int j = 0;
        for(int i = 0; i < n; i++){
            char v = x.charAt(i);
            if(v == '+' || v == '-' || v == '*' || v == '/'){
                target = new Node(v);
                target.right = s.pop();
                target.right.parent = target;
                target.left = s.pop();
                target.left.parent = target;
                s.push(target);               
                if(v == '+'){
                    if(Character.getNumericValue(target.left.data) > 0 && Character.getNumericValue(target.right.data) > 0){
                       Ans[j] = Character.getNumericValue(target.left.data) + Character.getNumericValue(target.right.data); 
                       j++;
                    }
                    else if(Character.getNumericValue(target.left.data) > 0){
                       Ans[j-1] = Character.getNumericValue(target.left.data) + Ans[j-1];
                    }
                    else if(Character.getNumericValue(target.right.data) > 0){
                       Ans[j-1] = Ans[j-1] + Character.getNumericValue(target.right.data);
                    }
                    else {
                       Ans[j-2] = Ans[j-2] + Ans[j-1];
                       j--;
                    }
                }
                else if(v == '-'){
                   if(Character.getNumericValue(target.left.data) > 0 && Character.getNumericValue(target.right.data) > 0){
                       Ans[j] = Character.getNumericValue(target.left.data) - Character.getNumericValue(target.right.data); 
                       j++;
                    }
                    else if(Character.getNumericValue(target.left.data) > 0){
                       Ans[j-1] = Character.getNumericValue(target.left.data) - Ans[j-1];
                    }
                    else if(Character.getNumericValue(target.right.data) > 0){
                       Ans[j-1] = Ans[j-1] - Character.getNumericValue(target.right.data);
                    }
                    else {
                       Ans[j-2] = Ans[j-2] * Ans[j-1];
                       j--;
                    }
                }
                else if(v == '*'){
                    if(Character.getNumericValue(target.left.data) > 0 && Character.getNumericValue(target.right.data) > 0){
                       Ans[j] = Character.getNumericValue(target.left.data) * Character.getNumericValue(target.right.data); 
                       j++;
                    }
                    else if(Character.getNumericValue(target.left.data) > 0){
                       Ans[j-1] = Character.getNumericValue(target.left.data) * Ans[j-1];
                    }
                    else if(Character.getNumericValue(target.right.data) > 0){
                       Ans[j-1] = Ans[j-1] * Character.getNumericValue(target.right.data);
                    }
                    else {
                       Ans[j-2] = Ans[j-2] * Ans[j-1];
                       j--;
                    }
                }
                else if(v == '/'){
                    if(Character.getNumericValue(target.left.data) > 0 && Character.getNumericValue(target.right.data) > 0){
                       Ans[j] = Character.getNumericValue(target.left.data) / Character.getNumericValue(target.right.data); 
                       j++;
                    }
                    else if(Character.getNumericValue(target.left.data) > 0){
                       Ans[j-1] = Character.getNumericValue(target.left.data) / Ans[j-1];
                    }
                    else if(Character.getNumericValue(target.right.data) > 0){
                       Ans[j-1] = Ans[j] / Character.getNumericValue(target.right.data);
                    }
                    else {
                       Ans[j-2] = Ans[j-2] * Ans[j-1];
                       j--;
                    }
                }                             
            }
            else {
                s.push(new Node(v));
            }
        }  
        Tree t = new Tree(s.top());
        t.bluidTree(s.top());
        t.printTree(Ans[0]);        
    }    

}
