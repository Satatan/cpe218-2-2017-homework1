/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1.java;

/**
 *
 * @author msi
 */
public class Node {
    Node left;
    Node right;
    Node parent;
    char data;

    public Node(char data) {
        this.data = data; //
    }
    
}
