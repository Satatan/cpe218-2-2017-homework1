/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1.java;

/**
 *
 * @author msi
 */
public class Stack {
    Node[] arr; // regular array
    int capacity;
    int size;

    public Stack(int cap){
        this.capacity = cap; //Assume Cap
        arr = new Node[capacity]; //Create array ที่มีขนาดเท่ากับ capacity
    }
    public Node top(){
        if (!isEmpty()){ //Check if stack is not empty 
            return arr[0]; //Return node pop
        }
        else{
            System.out.println("Stack Underflow!!!");
        }
        return null; // fix this (out of place)
    }
    
    public void push(Node node){
        if (!isFull()){
            arr[size] = node; //Get node to back 
            size++;
        }
        else{
            System.out.println("Stack Overflow!!!");
        }
    }
    public Node pop(){
        if (!isEmpty()){ //Check if stack is not empty 
            Node Itpop = arr[size-1]; //Copy node back 
            arr[size-1] = null; //Let node back is null
            size--;
            return Itpop; //Return node pop
        }
        else{
            System.out.println("Stack Underflow!!!");
        }
        return null; // fix this (out of place)
    }
    public boolean isFull(){ //Check stack is full
        if(size == capacity) { //Check if size of Queue = capacity #is Full
            return true;
        }
        else return false; 
    }
    public boolean isEmpty(){ //Check if Queue is empty node
        if(size == 0){
            return true;
        }
        else return false; 
    }
}
