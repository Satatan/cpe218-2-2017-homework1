/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1.java;

/**
 *
 * @author msi
 */
public class Tree {
    int n = 0;
    Node root;
    Node tail;
    String OP = "";
    public Tree(Node root){
        this.root = root;  
        tail = root;
        while(tail.right != null){
            tail = tail.right;
        }
    }
    public void bluidTree(Node travel){
        travel = travel.left;
        if(travel != root.left) OP += "(";
        if(travel.data == '+' || travel.data == '-' || travel.data == '*' || travel.data == '/'){           
            bluidTree(travel);           
        }
        else {
            OP += Character.toString(travel.data);
        }       
        travel = travel.parent;
        OP += Character.toString(travel.data);
        travel = travel.right;
        if(travel.data == '+' || travel.data == '-' || travel.data == '*' || travel.data == '/'){
            bluidTree(travel);
        }
        else {
            OP += Character.toString(travel.data);
        }
        if(travel != tail) OP += ")";
        travel = travel.parent;
    }
    public void printTree(int ans){
        System.out.print(OP + " = ");
        System.out.println(ans);
    }
}
